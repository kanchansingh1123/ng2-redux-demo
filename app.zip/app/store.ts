import { INCREMENT } from './actions';
import { tassign } from 'tassign';
import { Map } from 'immutable';

export const INITIAL_STATE: IAppState = {
    counter: 0/*,
    messaging: {
        newMessage: 5
    }*/
}

export interface IAppState {
    counter: number;
    // messaging?: {
    //     newMessage: number
    // }
}

// using tassing
export function rootReducer(state: IAppState, action): IAppState {
    switch(action.type) {
        case INCREMENT: 
               // return {counter: state.counter + 1};      
               //return Object.assign({}, state, { counter: state.counter + 1 }) 
               return tassign(state, { counter: state.counter + 1 });
    }
    return state;
}

// using immutable instead of tassign
/*export function rootReducer(state: Map<string, any>, action): Map<string, any> {
    switch(action.type) {
        case INCREMENT: 
               // return {counter: state.counter + 1};      
               //return Object.assign({}, state, { counter: state.counter + 1 }) 
               return state.set('counter', state.get('counter') + 1);
    }
    return state;
}*/