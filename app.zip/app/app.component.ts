import { Component, OnDestroy } from '@angular/core';
import { NgRedux, select } from 'ng2-redux';
import { IAppState } from './store';
import { INCREMENT } from './actions';
import { Map } from 'immutable';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnDestroy {
  title = 'app';

  @select('counter') count; 

  //@select(s => s.get('counter')) count; /** Using mutable objects */

  // messaging.newMessages using array
  //@select(['messaging', 'newMessages']) newMessages;

  // using arrow function
  //@select((s: IAppState) => s.messaging.newMessage) newMessages;

  constructor(private ngRedux: NgRedux<IAppState>) {
    // ngRedux.subscribe(() => {
    //   this.counter = ngRedux.getState().counter;
    // });
  }

  /*constructor(private ngRedux: NgRedux<Map<string, any>>) {
    
  }*/

  increment() {
    //this.counter++;
    this.ngRedux.dispatch({type: INCREMENT});
  }

  ngOnDestroy() {
    
  }
}
